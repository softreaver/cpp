#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <fstream>

using namespace std;

/** \brief Permet de m�langer les lettres d'un mot
 *
 * \param <string> Le mot � m�langer
 * \return <string> Le mot m�lang�
 *
 */
string melangerLettres(string a);

/** \brief Permet de charger un mot au hasard dans un fichier dictionnaire
 *
 * \param <string> nom du fichier.
 * \return <string> le mot pioch� au hasard
 *
 */
string chargerLeMot(string a);

int main()
{
    string const dico("dico.txt");
    string motMystere(""), motMelange(""), reponse("");
    bool recommencer;
    int essais;
    string choix;
    char rep;

    do
    {
        essais = 0;
        //1 : Choix du mot myst�re

        choix1:
        do
        {
            cout << endl << "Jouer seul ? (o/n)" << endl;
            cin >> choix;
        }while(choix.size() < 1 || choix.size() > 1);
        rep = choix[0];

        switch(rep)
        {
        case 'o':
            motMystere = chargerLeMot(dico);
        case 'O':
            motMystere = chargerLeMot(dico);
            break;
        case 'n':
            cout << "Joueur 1, saisissez un mot :"<<endl;
            cin >> motMystere;
            for(int i = 0; i < 30; i++)
            {
                cout << endl;
            }
        case 'N':
            cout << "Joueur 1, saisissez un mot :"<<endl;
            cin >> motMystere;
            for(int i = 0; i < 30; i++)
            {
                cout << endl;
            }
            break;
        default:
            goto choix1;
        }

        //2 : on m�lange les lettres du mot
        motMelange = melangerLettres(motMystere);

        //3 : On demande � l'utilisateur de retrouver le mot myst�re
        cout << "Quel est ce mot ? (" << motMelange << ")" << endl;

        do
        {
            cin >> reponse;
            if(reponse != motMystere)
            {
                cout << "Ce n'est pas le mot !" << endl;
                essais++;
                if(essais >= 5)
                    break;
                cout << "Il vous reste " << 5-essais << " essai(s)" << endl;
            }
            else
            {
                cout << "Bravo!" << endl;
            }
        }while(reponse != motMystere);

        if(essais >= 5)
            cout << "Perdu ! Le mot mystere etait : " << motMystere << endl;

choix2:
        do
        {
            cout << endl << "Voulez-vous rejouer une partie ? (o/n)" << endl;
            cin >> choix;
        }while(choix.size() < 1 || choix.size() > 1);

        rep = choix[0];
        switch(rep) // les switch ne prennent que des integer ou char(ASCII)
        {
        case 'o':
            recommencer = true;
        case 'O':
            recommencer = true;
            break;
        case 'n':
            recommencer = false;
        case 'N':
            recommencer = false;
            break;
        default:
            goto choix2;
        }

    }while(recommencer);

    cout << "Fin de partie, merci d'avoir joue." << endl;

    return 0;
}

string melangerLettres(string a)
{
    srand(time(0));
    int curseur;
    string ret("");

    while(a.size() > 0)
    {
        curseur = rand() % a.size();
        ret += a[curseur];
        a.erase(curseur, 1);
    }
    return ret;
}

string chargerLeMot(string a)
{
    ifstream file(a.c_str());
    string ret;
    int nombreDeLigne(0), position(0);

    if(file)
    {
        cout << "Chargement en cours ..." << endl;
        while(getline(file, ret))
        {
            nombreDeLigne++;
        }
        srand(time(0));
        position = rand() % nombreDeLigne;
        position++;
        file.clear(); // enlever l'EOF flag pour pouvoir de nouveau utiliser la fonction seekg()
        file.seekg(0, ios::beg);

        for(int i = 0; i < position; i++)
        {
            getline(file, ret);
        }
        return ret;
    }
    else
    {
        return "ERREUR";
    }
}
